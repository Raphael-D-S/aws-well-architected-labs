<template>
   <footer class="site-footer">
    <div class="row column">
      <nav class="footer-nav">
        <ul>
          <li><a href="index.html">Home</a></li>
        </ul>
      </nav>
    </div>
    <div class="row column">
      <div class="footer-legal">
        &copy;Blue Car Inc<br>
        All Rights Reserved
      </div>
    </div>
  </footer>
</template>